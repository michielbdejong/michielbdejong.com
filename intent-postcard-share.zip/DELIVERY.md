# Exact artifact delivery protocol

Read this together with `intent-postcard/SKILL.md`. Follow the user's current request.
This protocol applies on first open and after every edit. Merely attaching the
image or describing the intent tree does not provide the interactive experience.

## 1. Identify actual session capabilities

You need file extraction, Node.js 22+ execution and a way to return downloadable
files. Inspect the tools available in your current session; do not assume tools
from another assistant's environment exist. Rendering needs no network or packages.

There are three distinct presentation capabilities:

- **File links and inline images:** return the full interactive HTML as a link and
  embed the PNG using Markdown. This is the baseline delivery used by this project.
- **An actual HTML artifact/preview tool:** if available and authorized, load the
  complete generated HTML into that tool, including its CSS, script and embedded
  history. Keep the download links as a portable fallback. Do not replace the full
  viewer with just its SVG, a screenshot, a code block or a newly improvised viewer.
- **A browser tool:** useful to test the viewer, but opening a page inside your
  tool does not guarantee the user sees it. Still return the HTML link explicitly.

A skill file cannot enable a missing artifact tool or make a chat client execute
HTML. If HTML is sanitized or downloaded, say "Download the HTML and open it in
 your browser for the tree and history." If execution itself is unavailable, return
links to extracted existing files if possible and state the missing capability;
do not claim to have created or tested an updated artifact.

## 2. Produce canonical files

On first open, use the included `postcard/postcard.json` without changing history.
For an edit, use the skill's `add-child` or `update` operation first, with the actual
latest base revision and an appropriate component intent. Render into a new folder.
Then run the delivery helper against that new history to produce a fresh, complete
viewer and a ready-to-use response. Never link back to the initial ZIP's index.html
after editing: that would show the old revision.

From the extracted bundle root, in a workspace supporting absolute file links:

```sh
node intent-postcard/scripts/deliver.mjs \
  --history postcard/postcard.json \
  --out /workspace/artifacts/postcard-delivery-r5 --links local
```

In a ChatGPT code-execution environment that exposes `/mnt/data` through sandbox
file links, use its actual mounted paths, for example:

```sh
node intent-postcard/scripts/deliver.mjs \
  --history postcard/postcard.json \
  --out /mnt/data/postcard-delivery-r5 --links sandbox
```

These are alternatives, not commands to run blindly. Check which file-link syntax
your client supports. After an edit, substitute the new history path, revision and
unused output folder. The helper validates the history, renders HTML/PNG/SVG/JSON,
copies the complete viewer to `index.html`, and writes `RESPONSE.md`. It does not
perform the edit, invoke a model, inspect the drawing or publish a website.

If your client uses uploaded-file IDs or attachment tools instead of file paths,
attach the generated files using that mechanism and substitute its actual returned
URLs. Do not invent public URLs, attachment IDs or sandbox links outside a supported
sandbox. Do not return a path from the original author's filesystem.

## 3. Check the result before delivery

- Inspect the rendered PNG; revise drawing mistakes when tools permit.
- Confirm HTML includes `id="tree"`, `id="commits"` and `id="timeline"` and the
  latest history. Check that `index.html` and `postcard.html` are identical.
- If browser tooling exists, open the HTML, select Seine and a boat, click a history
  commit and return to the latest revision. On narrow screens use the header links
  to reach the panels below the drawing. Check no JavaScript errors appear.
- Confirm preserved branches and prior events remain unchanged for scoped edits.
- Confirm final file links refer to files that actually exist in this session.

Do not assert browser or visual checks you could not perform. State the specific
limit briefly and still deliver the files you successfully produced.

## 4. Final response contract

Use the generated `RESPONSE.md` as the actual response body, not merely as another
file for the user to download. Prepend a short description of the edit and actual
checks performed. It includes:

1. A prominent **Open the interactive postcard — component tree and diff-intent
   history** link to the latest full HTML.
2. The revision number and how to reach both panels.
3. An inline PNG preview using `![description](actual-image-link)`.
4. The latest downloadable canonical JSON and SVG.

For native HTML artifact interfaces, also show the full viewer in the native
artifact panel. For plain chat interfaces, the inline PNG remains static; the HTML
link is where selection and replay happen. Be clear about this distinction.

On first open, briefly offer the concrete walkthrough: select Seine in Component
intents; click **Add boat** (revision 3), then **Redraw Seine** (revision 4); return
to revision 5 to see the perspective tower. After further edits, discover the actual
history instead of assuming revision 5 remains latest.

When returning a ZIP, include the updated skill, README, handoff, this protocol,
latest JSON/HTML/PNG/SVG and a root index.html copied from the latest HTML. Keep
original user uploads intact. Summarize latest revision dynamically from the JSON;
old documentation may describe the baseline five-revision example.
