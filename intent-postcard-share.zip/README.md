# Start here: a postcard you can keep editing in chat

This bundle contains a Paris postcard, its editable intent tree and history, and a
portable skill for an AI assistant to create further revisions. It is a small
experiment in maintaining **what a drawing means** alongside **how it is drawn**.

You do not need the original conversation, repository, hosted website or an API
key. You do need an assistant that can extract files and execute Node.js 22+ if
you want it to make edits. Merely opening the HTML lets you view and explore it.
The skill does not supply an AI model: the assistant in your conversation authors
the changes, subject to that service's normal capabilities and usage limits.

## What “show the artifact” means

The assistant should return a prominent link to the complete interactive HTML,
an inline image preview, and the latest history JSON. A client with an HTML
artifact panel can display the full viewer there; other clients require opening
the HTML link in a browser. This package cannot add a missing client capability.
`DELIVERY.md` provides exact steps and the skill includes a delivery script that
prepares the files and response links for every revision.

## Open the full experience

Open **`index.html` at the root of this ZIP** after extracting it. This is the
interactive workspace, with the drawing, **Component intents** tree and
**Diff intents · history**. On a narrow screen the panels are below the drawing;
use the **Component tree** and **Diff-intent history** links at the top to jump
to them. `postcard/postcard.html` is the same workspace.

PNG and SVG files are only image previews. Opening one does not show the tree or
history. If a chat displays only a picture, ask it to provide the interactive HTML
file, or to open that HTML in its browser if supported. Some chat clients require
downloading HTML and opening it in an external browser to run its interactions.

## First use in a new chat

**One-sentence instruction to paste alongside the ZIP:**

> Extract this ZIP, read intent-postcard/SKILL.md and DELIVERY.md, and follow their delivery workflow to show the full interactive postcard with its component tree and diff-intent history, using scripts/deliver.mjs and its generated response after each edit.


Upload this ZIP and send the following message (replace the last sentence with
your own request):

> This is an editable intent-postcard project, not just an image. Extract the ZIP,
> read README.md, ASSISTANT_HANDOFF.md and intent-postcard/SKILL.md, then inspect
> postcard/postcard.json and the current image. Use the included scripts to
> continue the project. Preserve its history and unrelated components, visually
> inspect your result, and return the updated HTML, PNG and history JSON.
> First open the interactive index.html workspace, including its Component intents
> tree and Diff intents history—not just the PNG or SVG. If your interface cannot
> display interactive HTML, give me a download link and explain how to open it in
> a browser. Show me how to select the Seine and compare Add boat with Redraw Seine.

Uploading without a message may not tell a fresh assistant to use the package.
The files do not automatically install a named skill. If your assistant cannot
extract the ZIP, extract it yourself and supply the handoff, skill and history
through its supported project/file mechanism. If it cannot execute code, it can
explain the drawing or propose edits, but cannot complete this rendering workflow.

## What you can do

- **Explore:** extract the ZIP and open `index.html` in a browser.
  Select a component in the tree to highlight its strokes. Use the timeline or
  named history entries to compare revisions. Expand a component's strokes for
  low-level details. The viewer works offline and has no AI editing textbox.
- **Edit through chat:** ask “Add a third boat to the Seine, keeping the existing
  boats” or “Make the tower's upper ironwork more detailed.” The assistant changes
  the appropriate part and returns a new artifact.
- **Compare approaches:** ask “Add a boat incrementally, then make a separate full
  Seine redraw from the same intent so I can compare them.” These should become
  separate history entries, not overwrite each other.
- **Create another postcard:** ask the assistant to use the skill to create a new
  scene and history. This drawing language is deliberately small; see limitations
  in the handoff. It is not an unrestricted image-generation service.
- **Continue later:** save the latest returned JSON or use **Save history** in its
  viewer. Supply that file with this skill in a new chat. Each HTML is a snapshot;
  previous downloads do not automatically update.
- **Share:** send the HTML for interactive exploration, PNG/SVG for the finished
  picture, or the whole bundle for continued editing. HTML and JSON expose the
  recorded drawing requests and rationale as well as the image.

## The two kinds of intent

**Component intents** describe the lasting content: “The Seine has two boats.”
They form the drawing's tree: postcard → Seine → individual boats, for example.

**Diff intents** describe a change: “Add boat.” They appear in history with the
base revision, affected component, rationale and resulting drawing. An addition
can refine the Seine's component intent while preserving the existing geometry.

The assistant authors the component structure alongside the drawing program.
It does not merely reverse-engineer labels from a finished flat picture.

## What is included

| File | Purpose |
| --- | --- |
| `index.html` | Start here: full interactive drawing, tree and history workspace |
| `DELIVERY.md` | Exact display workflow and capability fallbacks |
| `ASSISTANT_HANDOFF.md` | Context and operating instructions for a fresh assistant |
| `intent-postcard/SKILL.md` | Drawing language, commands, constraints and workflow |
| `intent-postcard/scripts/` | Standalone JavaScript compiler, renderer and viewer |
| `intent-postcard/examples/` | Editable JSON drawing-program examples |
| `postcard/postcard.json` | Canonical source and complete five-revision history |
| `postcard/postcard.html` | Offline interactive viewer with embedded history |
| `postcard/postcard.png` | Raster preview |
| `postcard/postcard.svg` | Scalable vector artwork |

The included latest revision is **5**, with the detailed Eiffel Tower in
three-quarter perspective, clouds, the Seine and two boats. The history also lets
you compare the incremental boat addition with the later full river redraw.

## Render without an assistant

With Node.js 22+ installed, run from the extracted bundle directory:

```sh
node intent-postcard/scripts/postcard.mjs render --history postcard/postcard.json --out rendered
```

No npm install, API key or network connection is required. Use a new output folder
each time. Rendering replays recorded geometry; it does not ask an AI to redraw.
A static website host can serve the HTML if you want a public browser link.
