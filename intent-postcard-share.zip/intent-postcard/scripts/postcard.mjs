import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {compileDrawingProgram} from './drawing-program.mjs';
import {renderDrawingPreview} from './drawing-preview.mjs';

export function makeTree(program,revision,id='scene') {
  const part=compileDrawingProgram(program);let serial=0;
  const walk=p=>({id:`r${revision}:${serial++}`,title:p.title,prompt:p.intent,hidden:false,stroke:null,children:[...p.strokes.map((stroke,i)=>({id:`r${revision}:stroke:${serial++}`,title:`Stroke ${i+1}`,prompt:p.intent,hidden:false,stroke,children:[]})),...p.parts.map(walk)]});
  return {...walk(part),id};
}
export function replay(history,revision=history.events.length) {
  let tree=null;
  for(const event of history.events.slice(0,revision)) {
    if(event.operation==='add-child') {
      let found=false;
      const add=n=>{
        if(n.id===event.target){
          found=true;
          if(n.stroke!==null)throw Error('Cannot add a child to a stroke');
          if(!Number.isInteger(event.index)||event.index<0||event.index>n.children.length)throw Error('Invalid child insertion index');
          const children=[...n.children];children.splice(event.index,0,event.node);return {...n,prompt:event.parentPrompt===undefined?n.prompt:event.parentPrompt,children};
        }
        return {...n,children:n.children.map(add)};
      };
      if(!tree)throw Error('Missing initial scene');tree=add(tree);if(!found)throw Error('History refers to a missing parent intent');
    }
    else if(event.operation && event.operation!=='replace')throw Error('Unsupported history operation');
    else if(event.target==='scene')tree=event.node;
    else {
      let found=false;
      const replace=n=>{if(n.id===event.target){found=true;return event.node;}return {...n,children:n.children.map(replace)};};
      if(!tree)throw Error('Missing initial scene');tree=replace(tree);if(!found)throw Error('History refers to a missing intent');
    }
  }
  return tree;
}
export function revise(history,source,target,request,why,expectedRevision) {
  if(![1,2].includes(history.version)||!Array.isArray(history.events))throw Error('Unsupported postcard artifact');
  if(expectedRevision!==history.events.length)throw Error('Stale base revision; reopen the latest artifact before editing');
  if(!request?.trim()||!why?.trim())throw Error('Record both the request and its rationale');
  const previous=replay(history);
  const find=n=>n?.id===target?n:n?.children.map(find).find(Boolean);
  const old=find(previous);
  if(previous&&!old)throw Error('Selected intention does not exist');
  if(!previous&&target!=='scene')throw Error('First event must create the scene');
  const revision=history.events.length+1;
  const node=makeTree(source.program,revision,target);node.hidden=old?.hidden||false;
  const next={...history,events:[...history.events,{revision,baseRevision:expectedRevision,target,request,why,authorship:'harness-authored drawing program',source,node}]};
  const tree=replay(next);let count=0;const visit=n=>{if(++count>2500)throw Error('Resulting document exceeds 2500 nodes');n.children.forEach(visit);};visit(tree);
  return next;
}
export function addChild(history,source,parentId,request,why,expectedRevision,index,parentPrompt) {
  validateArtifact(history);
  if(expectedRevision!==history.events.length)throw Error('Stale base revision; reopen the latest artifact before editing');
  if(typeof request!=='string'||!request.trim()||typeof why!=='string'||!why.trim())throw Error('Record both the request and its rationale');
  const find=n=>n.id===parentId?n:n.children.map(find).find(Boolean);
  const parent=find(replay(history));
  if(!parent)throw Error('Parent intention does not exist');
  if(parent.stroke!==null)throw Error('Cannot add a child to a stroke');
  if(parentPrompt!==undefined&&(typeof parentPrompt!=='string'||!parentPrompt.trim()||parentPrompt.length>2000))throw Error('Invalid parent intention');
  index=index===undefined?parent.children.length:index;
  if(!Number.isInteger(index)||index<0||index>parent.children.length)throw Error('Invalid child insertion index');
  const revision=history.events.length+1;
  const node=makeTree(source.program,revision,`r${revision}:0`);
  const event={operation:'add-child',revision,baseRevision:expectedRevision,target:parentId,index,request,why,authorship:'harness-authored drawing program',source,node};
  if(parentPrompt!==undefined)event.parentPrompt=parentPrompt;
  const next={...history,version:2,events:[...history.events,event]};
  validateArtifact(next);return next;
}
const escape=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function svg(tree) {
  const lines=n=>n.hidden?'':(n.stroke?`<line x1="${n.stroke.x1}" y1="${n.stroke.y1}" x2="${n.stroke.x2}" y2="${n.stroke.y2}" stroke="${escape(n.stroke.color)}" stroke-width="${n.stroke.width}" stroke-linecap="${n.stroke.width>8?'butt':'round'}"><title>${escape(n.prompt)}</title></line>`:'')+n.children.map(lines).join('');
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 620 640" role="img" aria-label="${escape(tree.title)}"><rect width="620" height="640" fill="#fcfaf5"/><circle cx="448" cy="172" r="46" fill="#efe7d2" opacity=".52"/><path d="M42 490 Q200 477 310 483 T578 477 L578 602 L42 602 Z" fill="#e5eeeb" opacity=".5"/>${lines(tree)}</svg>`;
}
export function validateArtifact(history) {
  if(![1,2].includes(history.version)||!Array.isArray(history.events)||history.events.length<1||history.events.length>1000)throw Error('Invalid artifact history');
  for(let i=0;i<history.events.length;i++) {
    const e=history.events[i];
    if(e.revision!==i+1||e.baseRevision!==i||typeof e.request!=='string'||typeof e.why!=='string'||!e.node||typeof e.target!=='string'||(e.operation!=='add-child'&&e.target!==e.node.id)||(e.operation==='add-child'&&history.version!==2))throw Error('Invalid history event');
    if(e.parentPrompt!==undefined&&(e.operation!=='add-child'||typeof e.parentPrompt!=='string'||!e.parentPrompt.trim()||e.parentPrompt.length>2000))throw Error('Invalid parent intention');
    const ids=new Set();let count=0;
    const walk=(n,depth=0)=>{
      if(!n||depth>20||++count>2500||typeof n.id!=='string'||ids.has(n.id)||typeof n.title!=='string'||typeof n.prompt!=='string'||typeof n.hidden!=='boolean'||!Array.isArray(n.children))throw Error('Invalid intent tree');
      ids.add(n.id);
      if(n.stroke!==null){const p=n.stroke;if(!p||!['x1','y1','x2','y2'].every(k=>Number.isFinite(p[k])&&Math.abs(p[k])<=1000)||!Number.isFinite(p.width)||p.width<=0||p.width>640||!/^#[0-9a-f]{6}$/i.test(p.color))throw Error('Invalid drawing geometry');}
      n.children.forEach(c=>walk(c,depth+1));
    };
    walk(replay(history,i+1));
  }
}
export async function writeArtifact(history,directory) {
  validateArtifact(history);
  const tree=replay(history);if(!tree)throw Error('Nothing to render');
  const template=await readFile(new URL('./viewer.html',import.meta.url),'utf8');
  const html=template.replace('/*POSTCARD_DATA*/',()=>JSON.stringify(history).replace(/</g,'\\u003c'));
  await mkdir(directory,{recursive:true});
  await writeFile(resolve(directory,'postcard.json'),JSON.stringify(history,null,2));
  await writeFile(resolve(directory,'postcard.svg'),svg(tree));
  await writeFile(resolve(directory,'postcard.html'),html);
  await writeFile(resolve(directory,'postcard.png'),Buffer.from((await renderDrawingPreview(tree)).split(',')[1],'base64'));
}
async function main() {
  const [command,...args]=process.argv.slice(2);const options={};
  if(args.length%2)throw Error('Every --option needs a value');
  for(let i=0;i<args.length;i+=2){if(!args[i].startsWith('--'))throw Error('Expected named options');options[args[i].slice(2)]=args[i+1];}
  if(!['create','update','add-child','render'].includes(command)||!options.out)throw Error('Use create/update/add-child/render with --out DIR; see SKILL.md');
  let history=options.history?JSON.parse(await readFile(options.history,'utf8')):{version:1,events:[]};
  if(command!=='render'){
    if(!options.program)throw Error('--program is required');
    if(command==='create'&&history.events.length)throw Error('Create requires empty history');
    if(command==='add-child'&&(!options.history||options.base===undefined||!options.parent))throw Error('Add-child requires --history, --base and --parent');
    if(command==='update'&&(!options.history||options.base===undefined||!options.target))throw Error('Update requires --history, --base and --target');
    const source=JSON.parse(await readFile(options.program,'utf8'));
    if(command==='add-child')history=addChild(history,source,options.parent,options.request||source.program.intent,options.why||source.explanation,Number(options.base),options.index===undefined?undefined:Number(options.index),options['parent-intent']);
    else history=revise(history,source,options.target||'scene',options.request||source.program.intent,options.why||source.explanation,command==='create'?0:Number(options.base));
  }else if(!options.history)throw Error('Render requires --history');
  // Use a new output directory for every revision, preserving existing artifacts.
  try {await readFile(resolve(options.out,'postcard.json'));throw Error('Output already exists; choose a new revision directory');}catch(e){if(e.code!=='ENOENT')throw e;}
  await writeArtifact(history,options.out);
  console.log(JSON.stringify({directory:resolve(options.out),revision:history.events.length,intents:(function list(n){return n.stroke?[]:[{id:n.id,title:n.title},...n.children.flatMap(list)]})(replay(history))},null,2));
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url))main().catch(e=>{console.error(e.message);process.exitCode=1;});
