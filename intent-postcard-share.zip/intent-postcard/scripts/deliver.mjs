// Render a complete revision and prepare a response with client-appropriate links.
import { readFile, writeFile, copyFile, access } from 'node:fs/promises';
import { resolve, join, sep } from 'node:path';
import { validateArtifact, writeArtifact } from './postcard.mjs';

const args=process.argv.slice(2), options={};
try {
  if(args.length%2)throw Error('Every option requires a value');
  for(let i=0;i<args.length;i+=2){
    if(!['--history','--out','--links'].includes(args[i]))throw Error('Unknown option: '+args[i]);
    options[args[i].slice(2)]=args[i+1];
  }
  if(!options.history||!options.out)throw Error('Use --history FILE --out NEW_DIRECTORY --links local|sandbox');
  const mode=options.links||'local';
  if(!['local','sandbox'].includes(mode))throw Error('--links must be local or sandbox');
  const out=resolve(options.out);
  if(mode==='sandbox'&&!out.startsWith('/mnt/data/'))throw Error('Sandbox download links require an output directory under /mnt/data/');
  try {await access(out);throw Error('Output directory already exists; choose a new delivery directory');}
  catch(e){if(e.code!=='ENOENT')throw e;}
  const history=JSON.parse(await readFile(resolve(options.history),'utf8'));
  validateArtifact(history);
  await writeArtifact(history,out);
  await copyFile(join(out,'postcard.html'),join(out,'index.html'));
  const link=name=>(mode==='sandbox'?'sandbox:':'')+join(out,name).split(sep).join('/').replaceAll(' ','%20');
  const revision=history.events.length;
  const response=`[Open the interactive postcard — component tree and diff-intent history](${link('index.html')})\n\nRevision ${revision}. Use **Component tree** and **Diff-intent history** at the top of the viewer to explore the parts and earlier revisions. If this chat downloads HTML, open the downloaded file in a browser.\n\n![Postcard preview — open the HTML above for the interactive tree and history](${link('postcard.png')})\n\n[Save editable history](${link('postcard.json')}) · [Download SVG](${link('postcard.svg')})\n`;
  await writeFile(join(out,'RESPONSE.md'),response);
  console.log(response);
  console.log('Delivery files created. Inspect the image and verify links in your client before reporting completion.');
} catch(e){console.error(e.message);process.exitCode=1;}
