// A small, bounded drawing language: model output is data, never evaluated JS.
const programObject = properties => ({type:'object',properties,required:Object.keys(properties),additionalProperties:false});
const programPoint = programObject({x:{type:'number'},y:{type:'number'}});
const commandList = {type:'array',items:{$ref:'#/$defs/command'}};
export const programSchema = {
  ...programObject({plan:{type:'string'},explanation:{type:'string'},program:{$ref:'#/$defs/part'}}),
  $defs:{
    part:programObject({title:{type:'string'},intent:{type:'string'},commands:commandList,parts:{type:'array',items:{$ref:'#/$defs/part'}}}),
    command:{anyOf:[
      programObject({op:{type:'string',enum:['path']},points:{type:'array',items:programPoint},color:{type:'string'},width:{type:'number'}}),
      programObject({op:{type:'string',enum:['curve']},points:{type:'array',items:programPoint},color:{type:'string'},width:{type:'number'}}),
      programObject({op:{type:'string',enum:['repeat']},count:{type:'integer'},dx:{type:'number'},dy:{type:'number'},commands:commandList}),
      programObject({op:{type:'string',enum:['mirror']},axisX:{type:'number'},commands:commandList})
    ]}
  }
};
export function compileDrawingProgram(program) {
  let parts=0,commands=0,strokes=0;
  const number=x=>{if(!Number.isFinite(x)||Math.abs(x)>1000)throw Error('Invalid program coordinate');return x;};
  const list=(v,max)=>{if(!Array.isArray(v)||v.length>max)throw Error('Drawing program is too large');return v;};
  const label=x=>{if(typeof x!=='string'||!x.trim()||x.length>160)throw Error('Invalid part title');return x;};
  function run(cmds,out,transform={sx:1,dx:0,dy:0},depth=0) {
    if(depth>6)throw Error('Drawing program nesting exceeds limit');
    for(const c of list(cmds,160)) {
      if(++commands>1200||!c)throw Error('Drawing program exceeds operation limit');
      if(c.op==='repeat') {
        if(!Number.isInteger(c.count)||c.count<1||c.count>32)throw Error('Invalid repeat count');
        number(c.dx);number(c.dy);
        for(let i=0;i<c.count;i++)run(c.commands,out,{...transform,dx:transform.dx+transform.sx*i*c.dx,dy:transform.dy+i*c.dy},depth+1);
      } else if(c.op==='mirror') {
        number(c.axisX);
        run(c.commands,out,transform,depth+1);
        run(c.commands,out,{...transform,sx:-transform.sx,dx:transform.dx+2*transform.sx*c.axisX},depth+1);
      } else if(c.op==='path'||c.op==='curve') {
        if(!/^#[0-9a-f]{6}$/i.test(c.color)||!Number.isFinite(c.width)||c.width<=0||c.width>640)throw Error('Invalid program stroke');
        let points=list(c.points,100).map(p=>({x:number(p.x),y:number(p.y)}));
        if(points.length<2)throw Error('A path needs at least two points');
        if(c.op==='curve') {
          if(points.length!==4)throw Error('A cubic curve needs four control points');
          const controls=points;
          points=Array.from({length:13},(_,i)=>{const t=i/12,u=1-t;return {x:u**3*controls[0].x+3*u*u*t*controls[1].x+3*u*t*t*controls[2].x+t**3*controls[3].x,y:u**3*controls[0].y+3*u*u*t*controls[1].y+3*u*t*t*controls[2].y+t**3*controls[3].y};});
        }
        points=points.map(p=>({x:number(transform.sx*p.x+transform.dx),y:number(p.y+transform.dy)}));
        for(let i=1;i<points.length;i++) {
          if(++strokes>400)throw Error('Drawing program exceeds 400 strokes');
          out.push({x1:points[i-1].x,y1:points[i-1].y,x2:points[i].x,y2:points[i].y,color:c.color,width:c.width});
        }
      } else throw Error('Unknown drawing operation');
    }
  }
  function part(p,depth=0) {
    if(!p||++parts>80||depth>6)throw Error('Too many intent parts');
    label(p.title);
    if(typeof p.intent!=='string'||!p.intent.trim()||p.intent.length>2000)throw Error('Invalid part intention');
    const output={title:p.title,intent:p.intent,strokes:[],parts:[]};
    run(p.commands,output.strokes);
    output.parts=list(p.parts,80).map(c=>part(c,depth+1));return output;
  }
  const result=part(program);if(!strokes)throw Error('Drawing program is empty');return result;
}
