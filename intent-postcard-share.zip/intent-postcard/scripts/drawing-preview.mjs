// Portable PNG rendering for Node and Workers using only Web APIs. Selection
// highlighting is omitted so the critic sees the drawing's actual colors.
export async function renderDrawingPreview(document) {
  const width=620,height=640,pixels=new Uint8Array(width*height*3);
  const rgb=hex=>[1,3,5].map(i=>parseInt(hex.slice(i,i+2),16));
  const paper=rgb('#fcfaf5');for(let i=0;i<pixels.length;i++)pixels[i]=paper[i%3];
  let work=0;
  function paint(bounds,color,inside,alpha=1) {
    work+=Math.max(0,Math.min(width,Math.ceil(bounds[2]))-Math.max(0,Math.floor(bounds[0])))*Math.max(0,Math.min(height,Math.ceil(bounds[3]))-Math.max(0,Math.floor(bounds[1])));
    if(work>20000000)throw Error("Preview raster budget exceeded");
    const c=rgb(color);
    for(let y=Math.max(0,Math.floor(bounds[1]));y<Math.min(height,Math.ceil(bounds[3]));y++)
      for(let x=Math.max(0,Math.floor(bounds[0]));x<Math.min(width,Math.ceil(bounds[2]));x++)
        if(inside(x+.5,y+.5)){const i=(y*width+x)*3;for(let k=0;k<3;k++)pixels[i+k]=Math.round(pixels[i+k]*(1-alpha)+c[k]*alpha);}
  }
  paint([402,126,494,218],'#efe7d2',(x,y)=>(x-448)**2+(y-172)**2<=46**2,.52);
  // Same two quadratic segments as the Elm canvas's fixed water tint.
  const edge=[];
  for(const [a,b,c] of [[[42,490],[200,477],[310,483]],[[310,483],[420,489],[578,477]]])
    for(let i=0;i<=40;i++){const t=i/40,u=1-t;edge.push([u*u*a[0]+2*u*t*b[0]+t*t*c[0],u*u*a[1]+2*u*t*b[1]+t*t*c[1]]);}
  paint([42,477,578,602],'#e5eeeb',(x,y)=>{const i=edge.findIndex(p=>p[0]>=x);if(i<1)return false;const a=edge[i-1],b=edge[i];return y>=a[1]+(b[1]-a[1])*(x-a[0])/(b[0]-a[0]);},.5);
  let count=0;
  function draw(n) {
    if(n.hidden)return;
    if(n.stroke) {
      if(++count>2500)throw Error('Preview too large');
      const s=n.stroke,dx=s.x2-s.x1,dy=s.y2-s.y1,len=dx*dx+dy*dy,r=s.width/2;
      paint([Math.min(s.x1,s.x2)-r,Math.min(s.y1,s.y2)-r,Math.max(s.x1,s.x2)+r,Math.max(s.y1,s.y2)+r],s.color,(x,y)=>{
        let t=len?((x-s.x1)*dx+(y-s.y1)*dy)/len:0;
        if(s.width>8&&(len===0||t<0||t>1))return false;
        t=Math.max(0,Math.min(1,t));return (x-s.x1-t*dx)**2+(y-s.y1-t*dy)**2<=r*r;
      });
    }
    n.children.forEach(draw);
  }
  draw(document);
  const raw=new Uint8Array(height*(1+width*3));
  for(let y=0;y<height;y++)raw.set(pixels.subarray(y*width*3,(y+1)*width*3),y*(1+width*3)+1);
  const compressed=new Uint8Array(await new Response(new Blob([raw]).stream().pipeThrough(new CompressionStream('deflate'))).arrayBuffer());
  const concat=arrays=>{const b=new Uint8Array(arrays.reduce((n,a)=>n+a.length,0));let i=0;for(const a of arrays){b.set(a,i);i+=a.length;}return b;};
  const u32=n=>new Uint8Array([(n>>>24)&255,(n>>>16)&255,(n>>>8)&255,n&255]);
  const chunk=(name,data)=>{const body=concat([new TextEncoder().encode(name),data]);let crc=0xffffffff;for(const b of body){crc^=b;for(let i=0;i<8;i++)crc=(crc>>>1)^((crc&1)?0xedb88320:0);}return concat([u32(data.length),body,u32((crc^0xffffffff)>>>0)]);};
  const png=concat([new Uint8Array([137,80,78,71,13,10,26,10]),chunk('IHDR',concat([u32(width),u32(height),new Uint8Array([8,2,0,0,0])])),chunk('IDAT',compressed),chunk('IEND',new Uint8Array())]);
  let binary='';for(let i=0;i<png.length;i+=8192)binary+=String.fromCharCode(...png.subarray(i,i+8192));
  return 'data:image/png;base64,'+btoa(binary);
}
